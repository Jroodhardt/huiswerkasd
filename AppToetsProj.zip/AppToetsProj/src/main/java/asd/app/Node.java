package asd.app;

public class Node<E>{
    Node<E> next;
    E data;
    public Node(E data, Node<E> next){
        this.data=data;
        this.next=next;
    }

    public void insert(){

    }
}
